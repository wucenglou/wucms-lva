<?php $__env->startSection("content"); ?>
    <div class="col-sm-8 blog-main">
        <form class="form-horizontal" action="/user/<?php echo e(\Auth::id()); ?>/setting" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="form-group">
                <label class="col-sm-2 control-label">用户名</label>
                <div class="col-sm-10">
                    <input class="form-control" name="username" type="text" value="<?php echo e($me->username); ?>">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">头像</label>
                <div class="col-sm-2">
                    <img  class="img-thumbnail" src="<?php echo e($me->avatar_url); ?>" alt="" class="img-rounded" style="border-radius:500px;">
                    <input class=" file-loading preview_input" type="file" value="用户名" style="width:72px" name="avatar_url">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label"></label>
            <button type="submit" class="btn btn-default">确认修改</button>
            </div>
        </form>
        <br>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\2022\php\wucms-lva\serve2\resources\views/user/setting.blade.php ENDPATH**/ ?>