
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="/">企鹅社区</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText"
                aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarText">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="/posts">首页</a>
                    </li>
                    

                    <?php $__currentLoopData = $navs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($nav['hidden'] != 1): ?>
                        <?php if(!empty($nav['children']) && $nav['hidden'] != 1): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="/cn/<?php echo e($nav['name']); ?>/<?php echo e($nav['id']); ?>" id="navbardrop"
                                data-bs-toggle="dropdown">
                                <?php echo e($nav['metaTitle']); ?>

                            </a>
                            
                            <div class="dropdown-menu">
                                <?php $__currentLoopData = $nav['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($n['hidden'] != 1): ?>
                                <a class="dropdown-item" href="/cn/<?php echo e($n['name']); ?>/<?php echo e($n['id']); ?>"><?php echo e($n['metaTitle']); ?></a>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            
                        </li>
                        <?php else: ?>
                            <li class="nav-item"><a class="nav-link"
                                    href="/cn/<?php echo e($nav['name']); ?>/<?php echo e($nav['id']); ?>"><?php echo e($nav['metaTitle']); ?></a>
                        <?php endif; ?>
                        </li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <form class="d-flex" role="search" action="/posts/search" method="GET" style="margin-left: 1rem">
                        <input class="form-control me-2" type="search" name="keyword"
                            value="<?php echo e(Request::input('keyword')); ?>" placeholder="Search" aria-label="Search">
                        <button class="btn btn-outline-success" type="submit">Search</button>
                    </form>
                </ul>
                <span class="navbar-text">
                    <div class="dropdown">
                        <?php if(Auth::check()): ?>
                            <button type="button" class="btn btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown">
                                <?php echo e(Auth::user()->username); ?>

                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="/user/<?php echo e(\Auth::id()); ?>">我的主页</a></li>
                                <li><a class="dropdown-item" href="/user/me/setting">个人设置</a></li>
                                <li><a class="dropdown-item" href="/logout">登出</a></li>
                            </ul>
                        <?php else: ?>
                            <a href="/login"><button type="button"
                                    class="btn btn-outline-primary me-2">登录</button></a>
                            <a href="/register"><button type="button" class="btn btn-outline-primary">注册</button></a>
                        <?php endif; ?>
                    </div>
                </span>
            </div>
        </div>
    </nav>
<?php /**PATH E:\code\2022\php\wucms-lva\serve2\resources\views/layout/nav.blade.php ENDPATH**/ ?>