


<?php $__env->startSection("content"); ?>
        <div class="col-sm-8 blog-main">
            <div class="blog-post">
                <div style="display:inline-flex">
                    <h2 class="blog-post-title"><?php echo e($post->title); ?>

                        <small> 
                            
                        </small>
                    </h2>
                </div>
                <p class="blog-post-meta"><?php echo e($post->updated_at); ?><a href="/user/<?php echo e($post->user->id); ?>">  作者:<?php echo e($post->user->username); ?></a></p>
                <p class="">
                <?php echo $post->content; ?>

                </p>
                
            </div>

            <div class="panel panel-default">
                <div class="panel-heading">发表评论</div>
                <ul class="list-group">
                    <form action="/posts/comment" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>"/>
                        <input type="hidden" name="cat_id" value="<?php echo e($post->cat_id); ?>"/>
                        <li class="list-group-item">
                            <textarea name="content" class="form-control" rows="10"></textarea>
                            <button class="btn btn-default" type="submit">提交</button>
                        </li>
                    </form>
                </ul>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">评论</div>
                <ul class="list-group">
                    <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <h5><?php echo e($comment->created_at); ?> --->> <?php echo e($comment->user->username); ?></h5>
                        <div>
                            <?php echo e($comment->content); ?>

                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>


        </div><!-- /.blog-main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\2022\php\wucms-lva\serve2\resources\views/post/show.blade.php ENDPATH**/ ?>