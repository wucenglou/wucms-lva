
<?php $__env->startSection('content'); ?>
    

    <div class="col-sm-8">
        <?php echo $__env->make('post.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="list-group" style="margin-top: 1rem">
            <?php if($cat): ?>
                分类：<?php echo e($cat->meta_title); ?>

            <?php endif; ?>
            <div class="list-group-item" style="border-radius: .5rem;">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="" style="padding: 1rem;border-bottom:1px solid #eee;">
                        <div class="d-flex w-100 justify-content-between">
                            <a href="/posts/<?php echo e($post->id); ?>">
                                <h5 class="mb-1"><?php echo e($post->title); ?><?php echo e($post->id); ?></h5>
                            </a>
                            <small class="text-muted"><?php echo e($post->user->username); ?></small>
                        </div>
                        <p class=""><?php echo Str::limit($post->content, 200, '...'); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div>
            <?php echo e($posts->links()); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\2022\php\wucms-lva\serve2\resources\views/post/index.blade.php ENDPATH**/ ?>