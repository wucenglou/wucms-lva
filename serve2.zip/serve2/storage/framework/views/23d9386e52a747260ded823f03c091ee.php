

<?php $__env->startSection("content"); ?>

    <div class="alert alert-success" role="alert">
        下面是搜索"<?php echo e($query); ?>"出现的文章，共<?php echo e($posts->total()); ?>条
    </div>

    <div class="col-sm-8 blog-main">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="blog-post">
                <h2 class="blog-post-title"><a href="/posts/<?php echo e($post->id); ?>" ><?php echo e($post->title); ?></a></h2>
                <p class="blog-post-meta"><?php echo e($post->created_at->toFormattedDateString()); ?> by <a href="#">Mark</a></p>

                <p><?php echo Str::limit($post->content, 200, '...'); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="pull-right paginate">
           <?php echo e($posts->links()); ?>

        </div>
    </div><!-- /.blog-main -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\2022\php\wucms-lva\serve2\resources\views/post/search.blade.php ENDPATH**/ ?>