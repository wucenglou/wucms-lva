<?php $__env->startSection('content'); ?>
    <div class="col-sm-8">
        <blockquote>
            <p>
                <img src="<?php echo e($user->avatar_url); ?>" alt="" class="img-rounded" style="border-radius:500px; height: 40px">
                <?php echo e($user->username); ?>

            </p>
            <footer>关注：<?php echo e($user->stars_count); ?>｜粉丝：<?php echo e($user->fans_count); ?>｜文章：<?php echo e($user->posts_count); ?></footer>
            <?php echo $__env->make('user.badges.like', ['target_user' => $user], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </blockquote>
    </div>
    <div class="col-sm-8 blog-main">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button"
                    role="tab" aria-controls="home" aria-selected="true">文章</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button"
                    role="tab" aria-controls="profile" aria-selected="false">关注</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button"
                    role="tab" aria-controls="contact" aria-selected="false">粉丝</button>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="blog-post" style="margin-top: 30px">
                        <?php \Carbon\Carbon::setLocale('zh'); ?>
                        <p class=""><a href="/user/<?php echo e($post->user_id); ?>"><?php echo e($post->user->name); ?></a>
                            <?php echo e($post->created_at->diffForHumans()); ?></p>
                        <p class=""><a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></p>
                        <p><?php echo Str::limit($post->content, 100, '...'); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                <?php $__currentLoopData = $stars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $star): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $suser = $star->suser()->first(); ?>
                    <div class="blog-post" style="margin-top: 30px">
                        <p class=""><a href="/user/<?php echo e($suser->id); ?>"><?php echo e($suser->username); ?></a></p>
                        <p class="">关注：<?php echo e($suser->stars()->count()); ?> | 粉丝：<?php echo e($suser->fans()->count()); ?>｜
                            文章：<?php echo e($suser->posts()->count()); ?></p>

                        <?php echo $__env->make('user.badges.like', ['target_user' => $suser], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                <?php $__currentLoopData = $fans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $fuser = $fan->fuser()->first(); ?>
                    <div class="blog-post" style="margin-top: 30px">
                        <p class=""><a href="/user/<?php echo e($fuser->id); ?>"><?php echo e($fuser->username); ?></a></p>
                        <p class="">关注：<?php echo e($fuser->stars()->count()); ?> | 粉丝：<?php echo e($fuser->fans()->count()); ?>｜
                            文章：<?php echo e($fuser->posts()->count()); ?></p>

                        <?php echo $__env->make('user.badges.like', ['target_user' => $fuser], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\2022\php\wucms-lva\serve2\resources\views/user/show.blade.php ENDPATH**/ ?>