<div id="sidebar" class="col-xs-12 col-sm-4 col-md-4 col-lg-4">

    <div class="card" style="border-radius: .5rem">
        <div class="card-body">
            <h5 class="card-title">企鹅社区</h5>
            
            <p class="card-text">我们为了消除开发领域的知识不平等，建立了开放式协作的问答社区。探寻以开放、对等、共享的理念，凝聚开发者智慧，共同推动技术进步。
                欢迎你加入并贡献自己的智慧。</p>
             
        </div>
    </div>
    
    <aside id="widget-categories" class="widget panel panel-default">
        <div class="panel-heading">
            主题
        </div>
        <ul class="category-root list-group">
            
        </ul>
    </aside>
</div>
<?php /**PATH E:\code\2022\php\wucms-lva\serve2\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>