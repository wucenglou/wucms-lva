<?php if(count($errors)): ?>
<div class="alert alert-warning" role="alert">
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
       <strong><?php echo e($error); ?>!<br></strong>
      
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>   
<?php endif; ?><?php /**PATH E:\code\2022\php\wucms-lva\serve2\resources\views/layout/error.blade.php ENDPATH**/ ?>