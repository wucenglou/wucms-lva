<div id="sidebar" class="col-xs-12 col-sm-4 col-md-4 col-lg-4">

    <div class="card" style="border-radius: .5rem">
        <div class="card-body">
            <h5 class="card-title">企鹅社区</h5>
            {{-- <h6 class="card-subtitle mb-2 text-muted">Card subtitle</h6> --}}
            <p class="card-text">我们为了消除开发领域的知识不平等，建立了开放式协作的问答社区。探寻以开放、对等、共享的理念，凝聚开发者智慧，共同推动技术进步。
                欢迎你加入并贡献自己的智慧。</p>
             {{-- <a href="#" class="card-link"><button type="button" class="btn btn-outline-primary">加入社区</button></a>
            <a href="#" class="card-link"><button type="button" class="btn btn-outline-primary">发帖</button></a> --}}
        </div>
    </div>
    
    <aside id="widget-categories" class="widget panel panel-default">
        <div class="panel-heading">
            主题
        </div>
        <ul class="category-root list-group">
            {{-- @foreach ($topics as $topic)
            <li class="list-group-item">
                <a href="/topic/{{$topic->id}}">{{$topic->name}}</a>
            </li>
            @endforeach --}}
        </ul>
    </aside>
</div>
