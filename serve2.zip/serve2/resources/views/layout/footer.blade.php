<footer class="blog-footer" style="text-align: center">
    <p>
        Copyright@2020 企鹅社区 All right reserved. PHP version
        <?php echo phpversion(); ?>
    </p>
    <p>
        <a href="#">由 RowenGoo 设计和编码 ❤</a>
        <a>Laravel v<?php echo e(Illuminate\Foundation\Application::VERSION); ?> (PHP v<?php echo e(PHP_VERSION); ?>)</a>
    </p>
</footer>
